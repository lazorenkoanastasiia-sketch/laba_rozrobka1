import random
import storage


# === 1. ГРУПА: БАЗОВІ ОПЕРАЦІЇ (CRUD) ===

def add_task(args):
    """Додає нове завдання."""
    text = " ".join(args).strip()
    if not text:
        print("Помилка: текст завдання не може бути порожнім.")
        return

    tasks = storage.load_tasks()
    tasks.append({"text": text, "done": False})
    storage.save_tasks(tasks)
    print("Завдання додано.")


def show_tasks(args):
    """Показує всі завдання."""
    tasks = storage.load_tasks()
    if not tasks:
        print("Список порожній.")
        return

    for num, task in enumerate(tasks, start=1):
        mark = "[x]" if task["done"] else "[ ]"
        print(f"{num} {mark} {task['text']}")


def edit_task(args):
    """Змінює текст завдання."""
    if not args:
        print("Помилка: вкажіть номер завдання.")
        return

    tasks = storage.load_tasks()
    idx = storage.get_valid_index(args[0], tasks)
    if idx is None:
        return

    new_text = " ".join(args[1:]).strip()
    if not new_text:
        print("Помилка: новий текст не може бути порожнім.")
        return

    tasks[idx]["text"] = new_text
    storage.save_tasks(tasks)
    print("Завдання змінено.")


def done_task(args):
    """Позначає завдання виконаним."""
    if not args:
        print("Помилка: вкажіть номер завдання.")
        return

    tasks = storage.load_tasks()
    idx = storage.get_valid_index(args[0], tasks)
    if idx is None:
        return

    tasks[idx]["done"] = True
    storage.save_tasks(tasks)
    print("Завдання виконано.")


def delete_task(args):
    """Видаляє завдання."""
    if not args:
        print("Помилка: вкажіть номер завдання.")
        return

    tasks = storage.load_tasks()
    idx = storage.get_valid_index(args[0], tasks)
    if idx is None:
        return

    tasks.pop(idx)
    storage.save_tasks(tasks)
    print("Завдання видалено.")


# === 2. ГРУПА: АНАЛІТИКА ТА ІНСТРУМЕНТИ ===

def count_tasks(args):
    """Рахує всі завдання."""
    tasks = storage.load_tasks()
    print("Усього завдань:", len(tasks))


def show_progress(args):
    """Показує прогрес виконання завдань."""
    tasks = storage.load_tasks()
    finished = sum(1 for task in tasks if task["done"])
    remaining = len(tasks) - finished

    print("Виконано:", finished)
    print("Залишилося:", remaining)


def random_task(args):
    """Вибирає випадкове невиконане завдання."""
    tasks = storage.load_tasks()
    unfinished = [task for task in tasks if not task["done"]]

    if not unfinished:
        print("Немає невиконаних завдань.")
        return

    task = random.choice(unfinished)
    print("Випадкове завдання:", task["text"])


# === ДИСПЕТЧЕР КОМАНД ===

COMMANDS = {
    "add": add_task,
    "show": show_tasks,
    "edit": edit_task,
    "done": done_task,
    "delete": delete_task,
    "count": count_tasks,
    "progress": show_progress,
    "random": random_task,
}