import sys
from task_lib import COMMANDS


def get_help_text():
    """Автоматично збирає список усіх команд зі словника."""
    return ", ".join([*COMMANDS.keys(), "exit"])


def run_command(command, arguments):
    """Знаходить функцію у диспетчері та викликає її."""
    action = COMMANDS.get(command)
    
    if action:
        action(arguments)
    else:
        print(f"Невідома команда. Доступні: {get_help_text()}")


def interactive_mode():
    """Режим введення команд по черзі."""
    print(f"TaskHub CLI. Команди: {get_help_text()}")

    while True:
        user_line = input("> ").strip()
        if not user_line:
            print("Введіть команду.")
            continue

        word_list = user_line.split()
        command = word_list[0].lower()

        if command == "exit":
            break

        run_command(command, word_list[1:])

    print("Бувайте!")


def main():
    """Запускає програму."""
    if len(sys.argv) > 1:
        run_command(sys.argv[1].lower(), sys.argv[2:])
    else:
        interactive_mode()


if __name__ == "__main__":
    main()